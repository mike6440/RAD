//double ysi46041CountToRes(double c);
double ysi46041(double r, double *c); 
double ysi46000(double Rt, double Pt);
void therm_circuit_ground(double c, double C_max, double R_ref, double V_therm, double V_adc,
	double *v_t, double *R_t, double *P_t);